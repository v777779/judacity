1. Android Studio 3.0.1
2. AdMob and Interstital Ad support
   InterStitial Ad  called 1 time for 3 successful jokes
3. Tablet and non tablet screen support
4. AndroidTests  different for Paid and Free flavors
5. Gradle Test that starts server, run connected test, stops server`
    Group: BuiltIt BIgger.Verification.User Endpoint Test
	Task:  runThisUserEndpointTest
	
	Additional tasks:
	Task:  startServrManually   run server
	Task:  stopServrManually	stop server`
