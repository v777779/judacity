package ru.vpcb.popularmovie.utils;

/**
 * Exercise for course : Android Developer Nanodegree
 * Created: Vadim Voronov
 * Date: 29-Sep-17
 * Email: vadim.v.voronov@gmail.com
 */

public enum QueryType {
        POPULAR, NOWDAYS, TOPRATED, GENRES, REVIEW,PING

}
